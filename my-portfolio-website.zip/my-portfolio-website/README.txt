YOUR PERSONAL PORTFOLIO WEBSITE

FILES
- index.html: your complete responsive website. The styling and small script are included in this one file.

FIRST EDITS TO MAKE
1. Replace every instance of "Your Name" with the name you want visitors to see.
2. Replace "YN" in the profile tile with your initials.
3. Replace your.email@example.com with your real professional email address.
4. Replace the LinkedIn and GitHub links with your own profile links.
5. Add your real data projects to the Projects section as you complete them.

PREVIEW ON ANDROID
1. Download index.html to your phone.
2. Open your phone's Files app and find the downloaded file.
3. Tap it and choose Chrome or another browser if prompted.

PUBLISH ONLINE
You will need a hosting service to make the site available through a public website address. A simple option is GitHub Pages:
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example: my-portfolio.
3. Upload index.html to the top level of that repository.
4. Open the repository's Settings, then Pages.
5. Under Build and deployment, choose Deploy from a branch, select the main branch and the root folder, then Save.
6. GitHub will provide your public website address after deployment.

Before publishing, replace all sample contact details. Do not publish private information you do not want public.
